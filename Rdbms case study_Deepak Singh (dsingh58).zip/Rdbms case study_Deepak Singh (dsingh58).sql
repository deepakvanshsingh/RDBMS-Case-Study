--create database and use it
create database ABC_Company;
use  ABC_Company;

--create Location table 
Create Table Locations_dsingh58(Location_Id int, 
Street_Address varchar(100) not null,
Postal_Code int,
City Varchar(30) not null,
State varchar(30) not null,
Country varchar(30) not null,
constraint Location_Pk primary key(Location_Id),
constraint Postal_Check CHECK(Postal_Code like '[0-9][0-9][0-9][0-9][0-9][0-9]'));

insert into Locations_dsingh58 values(5,'Juang',546784,'Paris','Neulilly','France')

--create Jobs  table 
Create Table Jobs_dsingh58(Job_Id varchar(10), 
Job_Title varchar(40) not null,
Min_Salary Money,
Max_Salary Money,
constraint Job_Pk primary key(Job_Id));


insert into Jobs_dsingh58 values('4','KPO',15000,20000)

--create Departments table 
Create Table Departments_dsingh58(Department_Id int, 
Department_Name varchar(30) not null,
Location_Id int,
constraint Department_Pk primary key(Department_Id),
constraint Department_Fk foreign key(Location_Id) references Locations(Location_Id));

insert into Departments_dsingh58 values(80,'Fun & Activity',3)

--create Employees  table 
Create Table Employees_dsingh58(Employee_Id int not null constraint Employee_Pk primary key(Employee_Id), 
First_Name varchar(20) not null,
Last_Name varchar(20),
Email_Id varchar(50) not null,
Phone_Number char(10) not null,
Hire_Date date CHECK (Hire_Date< GETDATE()),
Job_Id varchar(10),
Salary money,
Manager_Id int,
Location_Id int, 
constraint Employee_Fk foreign key(Job_Id) references Jobs(Job_Id),
constraint Manager_Fk foreign key(Manager_Id) references Employees(Employee_Id),
constraint Employee_Location_Fk foreign key(Location_Id) references Locations(Location_Id));

insert into Employees_dsingh58(Employee_Id,First_Name,Last_Name,Email_Id,Phone_Number,Hire_Date,Job_Id,Salary,Manager_Id,Location_Id) 
                     values(5,'vinay','Singh','vinay@gmail.com','9068351032','2020/01/23','1',20000,1,1)



--1) Write a SQL statement to display Employee ID, First Name, Last Name, Salary of all employees.
select Employee_Id,First_Name,Last_Name,Salary from Employees_dsingh58;

--2) Write query to display all Job ID from Employees table without any repetition
select Distinct Job_Id from Employees_dsingh58;

--3) Display name of all employees whose city is �Paris�
--This question is wrong because there is no relationship between employee and location according to the table structure
--So i add one extra column in employee table name 'Location_Id'!!
select Concat(First_Name,' ',Last_Name) as [Employee Name] from Employees_dsingh58 where Location_Id in(select Location_Id from Locations_dsingh58 where City='Paris');
--or we can use inner joins as well
select Concat(First_Name,' ',Last_Name) as [Employee Name] from Employees_dsingh58 inner join Locations_dsingh58 on Employees.Location_Id=Locations.Location_Id where Locations.City='Paris';

--4)Display all employee details for employees whose department id is 20 or 40 or 60. 
select * from Employees_dsingh58 E inner join Departments_dsingh58 D on E.Location_Id=D.Location_Id where Department_Id in (20,40,60);

--5)Write query to display the first name, last name, department number and department name for each employee
select distinct First_Name, Last_Name, Department_Id,Department_Name from Employees_dsingh58 E inner join Departments_dsingh58 D on E.Location_Id=D.Location_Id;

--6)Write query to display first name, last name, department name, city and country for each employee whose salary is within 20000 to 80000. 
select First_Name, Last_Name, Department_Name,City, Country from Employees_dsingh58 E inner join Locations_dsingh58 L  
on E.Location_Id=L.Location_Id inner join Departments_dsingh58 D on E.Location_Id =D.Location_Id
--no relationship with Employee and Department accouding to given structure of table

--7)  Write SQL query to display first name of all employees whose name contains �ah�. 
select First_Name from Employees_dsingh58 where First_Name Like 'a%';

--8)  Write SQL query to display details of all employees who joined in the year 2005. 
select * from Employees_dsingh58 where Hire_Date Like '2005%'

--9) Display number of employees as per the Job ID.  
select COUNT(Employee_Id) as [Number of Employee] from Employees E inner join Jobs_dsingh58 J on E.Job_Id=J.Job_Id;

--10)Display all department names, where no employees tagged. 
select Department_Name from Departments_dsingh58 D inner join Employees_dsingh58 E on D.Location_Id=E.Location_Id ;
--not sure whether it is correct or not

--11) Write first name, last name and salary for those employee whose salary is greater than salary of the employee whose id is 123. 
select First_Name,Last_Name,Salary from Employees_dsingh58 where Salary>(select Salary from Employees_dsingh58 where Employee_Id=123);

--12) Display first name of employees with their manager�s first name.
select Distinct E.First_Name As Employee, M.First_Name As Manager from Employees_dsingh58 E, Employees_dsingh58 M where M.Employee_Id=E.Manager_Id;

--13) Write a stored procedure to display number of employees from the provided department id. 
--no relationship between with employee and department accourding to given table structure 

--14) Display name of all employees which are not tagged to any department. 
--no relationship between with employee and department accourding to given table structure 

--15) Write a stored procedure to update salary and location of the employee based on Employee ID. 

create procedure Update_Salary
@Salary Money,
@Location_Id int,
@Employee_Id int
As
begin
Update Employees_dsingh58 Set Salary=@Salary, Location_Id=@Location_Id where Employee_Id=@Employee_Id;
end

Exec Update_Salary 50000,3,1
