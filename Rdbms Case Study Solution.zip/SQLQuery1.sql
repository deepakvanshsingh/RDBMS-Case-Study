--create database and use it
create database ABC_Company;
use  ABC_Company;

--create Location table 
Create Table Locations(Location_Id int, 
Street_Address varchar(100) not null,
Postal_Code int,
City Varchar(30) not null,
State varchar(30) not null,
Country varchar(30) not null,
constraint Location_Pk primary key(Location_Id),
constraint Postal_Check CHECK(Postal_Code like '[0-9][0-9][0-9][0-9][0-9][0-9]'));

insert into Locations values(5,'Juang',546784,'Paris','Neulilly','France')

select *from Locations;
--create Jobs  table 
Create Table Jobs(Job_Id varchar(10), 
Job_Title varchar(40) not null,
Min_Salary Money,
Max_Salary Money,
constraint Job_Pk primary key(Job_Id));
 select * from Jobs
insert into Jobs values('4','KPO',15000,20000)
--create Departments table 
Create Table Departments(Department_Id int, 
Department_Name varchar(30) not null,
Location_Id int,
constraint Department_Pk primary key(Department_Id),
constraint Department_Fk foreign key(Location_Id) references Locations(Location_Id));

insert into Departments values(80,'Fun & Activity',3)
select * from Departments;

--create Employees  table 
drop table Employees

Create Table Employees(Employee_Id int not null constraint Employee_Pk primary key(Employee_Id), 
First_Name varchar(20) not null,
Last_Name varchar(20),
Email_Id varchar(50) not null,
Phone_Number char(10) not null,
Hire_Date date CHECK (Hire_Date< GETDATE()),
Job_Id varchar(10),
Salary money,
Manager_Id int,
Location_Id int, 
constraint Employee_Fk foreign key(Job_Id) references Jobs(Job_Id),
constraint Manager_Fk foreign key(Manager_Id) references Employees(Employee_Id),
constraint Employee_Location_Fk foreign key(Location_Id) references Locations(Location_Id));
select * from Locations
insert into Employees(Employee_Id,First_Name,Last_Name,Email_Id,Phone_Number,Hire_Date,Job_Id,Salary,Manager_Id,Location_Id) 
                     values(5,'vinay','Singh','vinay@gmail.com','9068351032','2020/01/23','1',20000,1,1)
insert into Employees(Employee_Id,First_Name,Last_Name,Email_Id,Phone_Number,Hire_Date,Job_Id,Salary,Manager_Id,Location_Id) 
                     values(123,'Vineet','Sharma','Vineet@gmail.com','6574839204','2008/01/23','3',20000,1,3)

select * from Employees;


--1) Write a SQL statement to display Employee ID, First Name, Last Name, Salary of all employees.
select Employee_Id,First_Name,Last_Name,Salary from Employees;
--2) Write query to display all Job ID from Employees table without any repetition
select Distinct Job_Id from Employees;
--3) Display name of all employees whose city is �Paris�
--This question is wrong because there is no relationship between employee and location according to the table structure
--So i add one extra column in employee table name 'Location_Id'!!
select Concat(First_Name,' ',Last_Name) as [Employee Name] from Employees where Location_Id in(select Location_Id from Locations where City='Paris');
--or we can use inner jins as well
select Concat(First_Name,' ',Last_Name) as [Employee Name] from Employees inner join Locations on Employees.Location_Id=Locations.Location_Id where Locations.City='Paris';

--4)Display all employee details for employees whose department id is 20 or 40 or 60. 
select * from Employees E inner join Departments D on E.Location_Id=D.Location_Id where Department_Id in (20,40,60);

--5)Write query to display the first name, last name, department number and department name for each employee
select distinct First_Name, Last_Name, Department_Id,Department_Name from Employees E inner join Departments D on E.Location_Id=D.Location_Id;

--6)Write query to display first name, last name, department name, city and country for each employee whose salary is within 20000 to 80000. 

--7)  Write SQL query to display first name of all employees whose name contains �ah�. 
select First_Name from Employees where First_Name Like 'a%';

--8)  Write SQL query to display details of all employees who joined in the year 2005. 
select * from Employees where Hire_Date Like '2005%'

--9) Display number of employees as per the Job ID.  
select COUNT(Employee_Id) as [Number of Employee] from Employees E inner join Jobs J on E.Job_Id=J.Job_Id;

--10)Display all department names, where no employees tagged. (wrong)
select Department_Name from Departments D inner join Employees E on D.Location_Id=E.Location_Id ;

--11) Write first name, last name and salary for those employee whose salary is greater than salary of the employee whose id is 123. 

select First_Name,Last_Name,Salary from Employees where Salary>(select Salary from Employees where Employee_Id=123);

--12) Display first name of employees with their manager�s first name.

select Distinct E.First_Name As Employee, M.First_Name As Manager from Employees E, Employees M where M.Employee_Id=E.Manager_Id;

--13) Write a stored procedure to display number of employees from the provided department id. 

--14) Display name of all employees which are not tagged to any department. 


--15) Write a stored procedure to update salary and location of the employee based on Employee ID. 

create procedure Update_Salary
@Salary Money,
@Location_Id int,
@Employee_Id int
As
begin
Update Employees Set Salary=@Salary, Location_Id=@Location_Id where Employee_Id=@Employee_Id;
end

Exec Update_Salary 50000,3,1
